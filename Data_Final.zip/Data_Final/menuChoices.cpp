#include "RiverSource.hpp"
int main()
{
	cout<<"Welcome to RiverSource!"<<endl;
	cout<<"================================"<<endl;
	char userChoice;
	cout<<"Please select an option:"<<endl;
	cout<<"1. Quit"<<endl;	
	cout<<"2. Load water level data"<<endl;
	bool done=false;
while (!done)
{
	switch(userChoice)
	{
		case ('1'):
		{
			cout<<"GoodBye"<<endl;
			done=true;
		}
		case ('2'):
		{
			string userInput;
			cout<<"Please load in water data for rivers"<<endl;
			bool inDone=false;
			waterLevel temp[365];
			cout<<"Enter a river name: ";
			getline(cin, userInput);
			int key=RiverSource.hashRiver(userInput);
			cout<<rivers[key].firstSection->name<<endl
			cout<<"Enter file name: ";
			getline(cin,userInput);
			ifstream fileRead(userInput);

			
				
				

			
		}
	}
}	
}
