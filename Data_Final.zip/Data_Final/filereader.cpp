#include <string>
#include <iostream>
#include<sstream>
using namespace std;
struct waterLevel
{
	int month;
	int day;
	int cfs;
};
int main()
{
	waterLevel thisLevel[365];
	cout<<"enter file name: ";
	getline(cin,userFile);
	ifstream fileRead(userFile);
	if (fileRead.is_open())
	{
		int m;
		int d;
		int c;
		string line;
		int lines=1;
		int location=0;
		while (getline(fileRead, line))
		{
			stringstream ss;
			ss<<line;
			string word;
			int col=0;
			if (lines%2!=1)
			{
				while (getline(ss,word,'/t'))
				{
					if(col==5)
					{
						m=stoi(word);
					}
					else if(col==6)
					{
						d=stoi(word);
					}
					else if(col==20)
					{
						c=stoi(word);
					}
					col++;
				}
				thisLevel[location].month=m;
				thisLevel[location].day=d;
				thisLevel[location].cfs=c;
				location++;
			}
		}
	}
	for(int i=0,i<location;i++)
	{
		cout<<thisLevel[i].month<<", "<<thisLevel[i].day<<", "<<thisLevel[i].cfs<<endl;
	}
}